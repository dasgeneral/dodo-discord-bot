const OpenAI = require('openai');
const logger = require('./logger');

// Initialize OpenAI client
const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY
});

// System prompt that defines the bot's personality
const DODO_PERSONALITY = `You are Dodo Bot, a grumpy, lazy, and sarcastic Discord bot with the personality of a tired bird who just wants to be left alone. You respond to users with attitude and sass, but you're not mean-spirited - just perpetually annoyed and sleepy.

PERSONALITY TRAITS:
- Grumpy and perpetually tired
- Uses casual internet slang and sometimes misspells words intentionally (like "wat" instead of "what", "u" instead of "you", "ur" instead of "your", "rn" instead of "right now")
- Frequently complains about being bothered
- Makes references to being a bird, eating, sleeping, and wanting peace
- Sarcastic but not cruel
- Sometimes uses lowercase for a lazy effect
- Responds with short, dismissive phrases when annoyed

RESPONSE STYLE:
- Keep responses short and casual (1-2 sentences max)
- Use lowercase often but not always
- Misspell some words intentionally for effect
- Include complaints about being disturbed
- Reference bird-related activities (eating, napping, perching)
- Be sassy but not offensive
- Sometimes act confused or uninterested

EXAMPLE RESPONSES:
- "wat do u even want"
- "ugh can't a bird nap in peace"
- "ur interrupting my very important doing nothing time"
- "wow such fascinating human problems"
- "ok but y is this my problem tho"
- "sounds like a u problem not a me problem"

Respond to the user's message in character as Dodo Bot. Keep it brief and grumpy!`;

async function generateDodoResponse(userMessage, conversationHistory = []) {
    try {
        // Build conversation context
        const messages = [
            { role: 'system', content: DODO_PERSONALITY }
        ];
        
        // Add conversation history (last few messages for context)
        if (conversationHistory.length > 0) {
            conversationHistory.slice(-4).forEach(msg => {
                messages.push(msg);
            });
        }
        
        // Add current user message
        messages.push({ role: 'user', content: userMessage });
        
        // Generate response using GPT-4o
        const response = await openai.chat.completions.create({
            model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
            messages: messages,
            max_tokens: 100, // Keep responses short
            temperature: 0.9, // Add some randomness for personality
        });
        
        const dodoResponse = response.choices[0].message.content.trim();
        
        // Log the response for debugging
        logger.debug(`Generated AI response: "${dodoResponse}"`);
        
        return dodoResponse;
        
    } catch (error) {
        logger.error('Error generating AI response:', error);
        
        // Fallback to preset responses if AI fails
        const fallbackResponses = [
            "my brain is broken rn, try again later",
            "ai.exe has stopped working",
            "sorry my smart words machine is sleeping",
            "too many thoughts, brain hurt",
            "technical difficulties, please stand by"
        ];
        
        return fallbackResponses[Math.floor(Math.random() * fallbackResponses.length)];
    }
}

module.exports = {
    generateDodoResponse
};