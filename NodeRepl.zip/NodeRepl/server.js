const express = require('express');
const app = express();
const port = process.env.PORT || 5000;

// Simple web interface to keep the bot alive
app.get('/', (req, res) => {
    res.send(`
        <h1>Dodo Bot Status</h1>
        <p>Bot is running and being grumpy as usual! 🦤</p>
        <p>Status: Online</p>
        <p>Server Time: ${new Date().toISOString()}</p>
    `);
});

app.get('/ping', (req, res) => {
    res.json({ status: 'alive', timestamp: Date.now() });
});

app.listen(port, '0.0.0.0', () => {
    console.log(`Web server running on port ${port}`);
});

// Start the Discord bot
require('./index.js');