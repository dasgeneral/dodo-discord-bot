const { SlashCommandBuilder } = require('discord.js');
const logger = require('../utils/logger');

// Creative excuses for being lazy or avoiding work
const excuses = [
    "sorry im allergic to productivity today",
    "my energy levels are critically low, need snacks first",
    "its too early... and also too late",
    "my brain is still buffering from yesterday",
    "im conserving energy for more important things like napping",
    "the wifi in my nest is down",
    "im on dodo time which moves slower than human time",
    "my motivation got lost in the mail",
    "technical difficulties: my give-a-care is broken",
    "im practicing the ancient art of doing nothing",
    "busy schedule: sleep from 9am to 5pm",
    "my to-do list is allergic to getting done",
    "im waiting for inspiration to strike... still waiting",
    "operating at 2% battery and no charger in sight",
    "mercury is in microwave so i cant do anything",
    "my attention span expired, please renew later",
    "im on strike against responsibilities",
    "doctor prescribed me 20cc of laziness daily",
    "software update required: installing procrastination v2.0",
    "sorry, thats future dodos problem"
];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('excuse')
        .setDescription('Get a creative excuse from Dodo Bot for avoiding work'),
    
    async execute(interaction) {
        try {
            // Pick a random excuse
            const randomExcuse = excuses[Math.floor(Math.random() * excuses.length)];
            
            // Add some lazy emojis
            const lazyEmojis = ['😴', '🦥', '💤', '😑', '🤷‍♂️'];
            const randomEmoji = lazyEmojis[Math.floor(Math.random() * lazyEmojis.length)];
            
            await interaction.reply({
                content: `${randomEmoji} ${randomExcuse}`,
                ephemeral: false
            });
            
            logger.info(`Excuse given: "${randomExcuse}" to ${interaction.user.tag}`);
            
        } catch (error) {
            logger.error('Error in excuse command:', error);
            
            if (!interaction.replied) {
                await interaction.reply({
                    content: 'cant even make excuses properly... thats my excuse 🤷‍♂️',
                    ephemeral: true
                });
            }
        }
    },
};