const { SlashCommandBuilder } = require('discord.js');
const logger = require('../utils/logger');

// Different moods with corresponding phrases and emojis
const moods = [
    {
        name: "grumpy",
        phrases: [
            "im in a TERRIBLE mood today",
            "everything is annoying me rn",
            "dont even talk to me",
            "ugh why is everyone so loud",
            "i hate mornings... and afternoons... and nights"
        ],
        emoji: "😤"
    },
    {
        name: "sleepy",
        phrases: [
            "zzz... wat... oh its u again",
            "5 more minutes pleaaaase",
            "why am i awake",
            "someone turn off the sun",
            "naptime is anytime"
        ],
        emoji: "😴"
    },
    {
        name: "hungry",
        phrases: [
            "WHERE IS MY FOOD",
            "someone better bring snacks",
            "my tummy is making weird noises",
            "feed me or leave me alone",
            "i could eat a whole pizza rn"
        ],
        emoji: "🍗"
    },
    {
        name: "confused",
        phrases: [
            "wat is happening",
            "i dont understand anything anymore",
            "brain.exe has stopped working",
            "too many words make dodo sad",
            "can someone explain... actually nevermind"
        ],
        emoji: "🤔"
    },
    {
        name: "lazy",
        phrases: [
            "moving is overrated",
            "why do things when u can do nothing",
            "productivity is for other people",
            "im one with the couch now",
            "effort? in THIS economy?"
        ],
        emoji: "🦥"
    }
];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('mood')
        .setDescription('Check what mood Dodo Bot is in today'),
    
    async execute(interaction) {
        try {
            // Pick a random mood
            const randomMood = moods[Math.floor(Math.random() * moods.length)];
            const randomPhrase = randomMood.phrases[Math.floor(Math.random() * randomMood.phrases.length)];
            
            await interaction.reply({
                content: `${randomMood.emoji} **${randomMood.name.toUpperCase()}** - ${randomPhrase}`,
                ephemeral: false
            });
            
            logger.info(`Mood check: ${randomMood.name} - "${randomPhrase}" to ${interaction.user.tag}`);
            
        } catch (error) {
            logger.error('Error in mood command:', error);
            
            if (!interaction.replied) {
                await interaction.reply({
                    content: 'my mood detector is broken... probably grumpy tho',
                    ephemeral: true
                });
            }
        }
    },
};