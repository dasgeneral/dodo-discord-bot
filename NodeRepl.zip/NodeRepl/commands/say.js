const { SlashCommandBuilder } = require('discord.js');
const logger = require('../utils/logger');

// Predefined quirky phrases for the Dodo Bot
const quirkyPhrases = [
    "wat u want man im eating",
    "stop",
    "go away",
    "leave me alone plz",
    "im busy rn",
    "why u disturbing me",
    "not now human",
    "dodo needs peace",
    "shoo shoo",
    "can't u see im vibing",
    "bruh moment",
    "seriously?",
    "nah fam",
    "dodo says no",
    "maybe later idk",
    "ur interrupting my nap",
    "what now???",
    "sigh... fine what is it",
    "this better be important",
    "dodo is not amused"
];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('say')
        .setDescription('Dodo Bot says something quirky!'),
    
    async execute(interaction) {
        try {
            // Pick a random phrase
            const randomPhrase = quirkyPhrases[Math.floor(Math.random() * quirkyPhrases.length)];
            
            await interaction.reply({
                content: randomPhrase,
                ephemeral: false
            });
            
            logger.info(`Said phrase: "${randomPhrase}" to ${interaction.user.tag}`);
            
        } catch (error) {
            logger.error('Error in say command:', error);
            
            if (!interaction.replied) {
                await interaction.reply({
                    content: 'wat... something broke. typical.',
                    ephemeral: true
                });
            }
        }
    },
};
