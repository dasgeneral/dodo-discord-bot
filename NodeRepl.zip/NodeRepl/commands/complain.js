const { SlashCommandBuilder } = require('discord.js');
const logger = require('../utils/logger');

// Random complaints and rants
const complaints = [
    "why is everything so LOUD all the time",
    "people keep expecting me to do things... ugh",
    "i asked for quiet time and got CHAOS instead",
    "mornings should be illegal",
    "whoever invented alarm clocks is my enemy",
    "why do humans talk so much",
    "food takes too long to arrive when im hungry",
    "being awake is exhausting",
    "everyone moves too fast, slow down people",
    "why cant everything just be delivered to my nest",
    "social interaction is overrated tbh",
    "the sun is too bright, the moon is too dark",
    "decisions are hard, can someone else choose",
    "why do weekends end so quickly",
    "noise pollution is ruining my vibe",
    "technology is confusing and scary",
    "people keep asking me to be productive",
    "why is water wet and fire hot, makes no sense",
    "gravity is annoying, i want to float",
    "someone keeps moving my stuff around"
];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('complain')
        .setDescription('Let Dodo Bot rant about something that\'s bothering it'),
    
    async execute(interaction) {
        try {
            // Pick a random complaint
            const randomComplaint = complaints[Math.floor(Math.random() * complaints.length)];
            
            // Add some random frustrated emojis
            const frustrationEmojis = ['😤', '😑', '🙄', '😮‍💨', '😒', '🤦‍♂️'];
            const randomEmoji = frustrationEmojis[Math.floor(Math.random() * frustrationEmojis.length)];
            
            await interaction.reply({
                content: `${randomEmoji} ugh... ${randomComplaint}`,
                ephemeral: false
            });
            
            logger.info(`Complained: "${randomComplaint}" to ${interaction.user.tag}`);
            
        } catch (error) {
            logger.error('Error in complain command:', error);
            
            if (!interaction.replied) {
                await interaction.reply({
                    content: 'great... now even my complaining is broken 😤',
                    ephemeral: true
                });
            }
        }
    },
};