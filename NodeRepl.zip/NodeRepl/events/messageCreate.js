const logger = require('../utils/logger');
const { generateDodoResponse } = require('../utils/aiConversation');

// Counter to track messages for random reactions
let messageCounter = 0;
const REACTION_FREQUENCY = 4; // React every 4 messages on average
const REPLY_FREQUENCY = 8; // Reply to messages every ~8 messages on average

// Conversation tracking
const activeConversations = new Map(); // userId -> { messageCount, lastActivity, history }
const MAX_CONVERSATION_LENGTH = 8; // Max messages in conversation before bot gets tired
const CONVERSATION_TIMEOUT = 300000; // 5 minutes timeout

// Random replies to messages
const randomReplies = [
    "wat",
    "why tho",
    "ok but did i ask",
    "interesting... anyway",
    "cool story bro",
    "and then what happened",
    "riveting stuff",
    "uh huh sure",
    "noted",
    "fascinating",
    "wow such insight",
    "deep thoughts",
    "big if true",
    "citation needed",
    "doubt",
    "seems legit",
    "sure thing chief",
    "absolutely not",
    "maybe idk",
    "valid point... not",
    "groundbreaking discovery",
    "revolutionary thinking",
    "mind = blown",
    "shocked pikachu face",
    "that's a hot take"
];

// Conversation responses when mentioned
const conversationStarters = [
    "wat do u want now",
    "oh great, another human needs something",
    "sigh... yes?",
    "wat is it this time",
    "make it quick im busy doing nothing",
    "u rang?",
    "this better be important",
    "wat could possibly be so urgent",
    "ugh fine wat",
    "do i have to?"
];

const conversationResponses = [
    "uh huh",
    "and?",
    "go on...",
    "riveting",
    "then wat",
    "sure whatever",
    "if u say so",
    "doubt it but ok",
    "fascinating stuff really",
    "wow amazing",
    "groundbreaking",
    "tell me more i guess",
    "uh sure",
    "seems legit",
    "big if true",
    "citation needed",
    "controversial take",
    "bold statement",
    "hot take alert",
    "noted i suppose"
];

const conversationEnders = [
    "ok im bored now bye",
    "this conversation has expired",
    "anyway gotta go do important bird stuff",
    "im done talking now",
    "conversation.exe has stopped working",
    "time for my scheduled nap",
    "social battery depleted",
    "thats enough human interaction for today",
    "k bye",
    "alright im out",
    "conversation over, dodo needs peace",
    "welp this got boring fast"
];

module.exports = {
    name: 'messageCreate',
    async execute(message) {
        // Ignore messages from bots
        if (message.author.bot) return;
        
        // Clean up expired conversations
        cleanupExpiredConversations();
        
        // Check if bot was mentioned/pinged
        const botWasMentioned = message.mentions.has(message.client.user);
        
        if (botWasMentioned) {
            await handleConversation(message);
            return; // Don't do random reactions if in conversation
        }
        
        // Check if user is in active conversation
        const userId = message.author.id;
        if (activeConversations.has(userId)) {
            await continueConversation(message);
            return; // Don't do random reactions if in conversation
        }
        
        // Regular message handling (reactions and random replies)
        messageCounter++;
        
        try {
            // Random chance to react (roughly every REACTION_FREQUENCY messages)
            const shouldReact = Math.random() < (1 / REACTION_FREQUENCY);
            
            // Random chance to reply (less frequent than reactions)
            const shouldReply = Math.random() < (1 / REPLY_FREQUENCY);
            
            if (shouldReact) {
                await reactToMessage(message);
                messageCounter = 0; // Reset counter
            }
            
            // Reply to message if triggered (separate from reactions)
            if (shouldReply && !shouldReact) { // Don't reply and react to same message
                await replyToMessage(message);
            }
            
        } catch (error) {
            logger.error('Error in messageCreate event:', error);
        }
    },
};

async function reactToMessage(message) {
    try {
        // Get available emojis from the guild
        const guild = message.guild;
        if (!guild) return;
        
        const emojis = guild.emojis.cache;
        
        if (emojis.size === 0) {
            // Fallback to Unicode emojis if no custom emojis available
            const unicodeEmojis = ['😴', '🦤', '🍗', '💤', '😑', '🙄', '😒', '🤨', '😮‍💨'];
            const randomEmoji = unicodeEmojis[Math.floor(Math.random() * unicodeEmojis.length)];
            await message.react(randomEmoji);
            logger.info(`Reacted with Unicode emoji ${randomEmoji} to message from ${message.author.tag}`);
            return;
        }
        
        // Pick a random custom emoji
        const emojiArray = Array.from(emojis.values());
        const randomEmoji = emojiArray[Math.floor(Math.random() * emojiArray.length)];
        
        // Check if bot has permission to add reactions
        const permissions = message.channel.permissionsFor(message.client.user);
        if (!permissions || !permissions.has('AddReactions')) {
            logger.warn('Missing ADD_REACTIONS permission in channel:', message.channel.name);
            return;
        }
        
        await message.react(randomEmoji);
        logger.info(`Reacted with ${randomEmoji.name} to message from ${message.author.tag}`);
        
    } catch (error) {
        // If custom emoji fails, try with a simple Unicode emoji
        try {
            await message.react('🦤'); // Dodo bird emoji as fallback
            logger.info('Used fallback dodo emoji reaction');
        } catch (fallbackError) {
            logger.error('Failed to react even with fallback emoji:', fallbackError);
        }
    }
}

async function replyToMessage(message) {
    try {
        // Check if bot has permission to send messages
        const permissions = message.channel.permissionsFor(message.client.user);
        if (!permissions || !permissions.has('SendMessages')) {
            logger.warn('Missing SEND_MESSAGES permission in channel:', message.channel.name);
            return;
        }
        
        // Pick a random reply
        const randomReply = randomReplies[Math.floor(Math.random() * randomReplies.length)];
        
        // Reply to the message
        await message.reply({
            content: randomReply,
            allowedMentions: { repliedUser: false } // Don't ping the user
        });
        
        logger.info(`Replied with "${randomReply}" to message from ${message.author.tag}`);
        
    } catch (error) {
        logger.error('Failed to reply to message:', error);
    }
}

async function handleConversation(message) {
    try {
        const userId = message.author.id;
        
        // Check if bot has permission to send messages
        const permissions = message.channel.permissionsFor(message.client.user);
        if (!permissions || !permissions.has('SendMessages')) {
            logger.warn('Missing SEND_MESSAGES permission in channel:', message.channel.name);
            return;
        }
        
        // Get user's message content (remove the bot mention)
        const userMessage = message.content.replace(/<@!?\d+>/g, '').trim();
        
        // Start new conversation or continue existing one
        if (!activeConversations.has(userId)) {
            // New conversation - use smart contextual response
            const contextualResponse = getContextualResponse(userMessage, true);
            
            await message.reply({
                content: contextualResponse,
                allowedMentions: { repliedUser: false }
            });
            
            // Track conversation
            activeConversations.set(userId, {
                messageCount: 1,
                lastActivity: Date.now(),
                lastUserMessage: userMessage
            });
            
            logger.info(`Started conversation with ${message.author.tag}: "${contextualResponse}"`);
        } else {
            // Continue existing conversation
            await continueConversation(message);
        }
        
    } catch (error) {
        logger.error('Error handling conversation:', error);
    }
}

async function continueConversation(message) {
    try {
        const userId = message.author.id;
        const conversation = activeConversations.get(userId);
        
        if (!conversation) return;
        
        // Update activity
        conversation.lastActivity = Date.now();
        conversation.messageCount++;
        
        // Get user's message content
        const userMessage = message.content.trim();
        
        // Check if bot should end conversation
        const shouldEndConversation = conversation.messageCount >= MAX_CONVERSATION_LENGTH || 
                                     Math.random() < 0.15; // 15% chance to randomly end
        
        if (shouldEndConversation) {
            // End conversation with contextual ending
            const ending = conversationEnders[Math.floor(Math.random() * conversationEnders.length)];
            
            await message.reply({
                content: ending,
                allowedMentions: { repliedUser: false }
            });
            
            activeConversations.delete(userId);
            logger.info(`Ended conversation with ${message.author.tag}: "${ending}"`);
        } else {
            // Continue conversation with contextual response
            const contextualResponse = getContextualResponse(userMessage, false);
            
            await message.reply({
                content: contextualResponse,
                allowedMentions: { repliedUser: false }
            });
            
            // Update conversation
            conversation.lastUserMessage = userMessage;
            
            logger.info(`Conversation response to ${message.author.tag}: "${contextualResponse}"`);
        }
        
    } catch (error) {
        logger.error('Error continuing conversation:', error);
    }
}

function getContextualResponse(userMessage, isStarter = false) {
    const msg = userMessage.toLowerCase();
    
    // Starter responses when first mentioned
    if (isStarter) {
        if (msg.includes('how are you') || msg.includes('how r u')) {
            return ['wat do u think... tired and grumpy as usual', 'do i look ok to u? spoiler: no', 'existing is exhausting thx for asking'][Math.floor(Math.random() * 3)];
        }
        if (msg.includes('hello') || msg.includes('hi') || msg.includes('hey')) {
            return ['wat do u want now', 'oh great another human', 'sigh... hi i guess'][Math.floor(Math.random() * 3)];
        }
        if (msg.includes('help') || msg.includes('can you')) {
            return ['depends wat u need but probably no', 'helping requires effort and im fresh out', 'maybe if u ask nicely... actually no'][Math.floor(Math.random() * 3)];
        }
        if (msg.includes('love') || msg.includes('like')) {
            return ['ew emotions', 'too wholesome for me', 'love is stored in the... wait no thats cringe'][Math.floor(Math.random() * 3)];
        }
        if (msg.includes('food') || msg.includes('eat')) {
            return ['now ur speaking my language', 'food is the only thing that matters', 'WHERE IS MY SNACK'][Math.floor(Math.random() * 3)];
        }
        if (msg.includes('sleep') || msg.includes('tired')) {
            return ['finally someone who gets it', 'sleep is life', 'nap time is anytime'][Math.floor(Math.random() * 3)];
        }
        if (msg.includes('fuck') || msg.includes('shit') || msg.includes('damn')) {
            return ['wow such language', 'mood tbh', 'big mood energy'][Math.floor(Math.random() * 3)];
        }
        // Default starters
        return conversationStarters[Math.floor(Math.random() * conversationStarters.length)];
    }
    
    // Continuation responses
    if (msg.includes('why') || msg.includes('how')) {
        return ['because reasons', 'thats just how it is deal with it', 'y do u ask so many questions'][Math.floor(Math.random() * 3)];
    }
    if (msg.includes('what') || msg.includes('wat')) {
        return ['u heard me', 'exactly wat i said', 'wat wat in the chat'][Math.floor(Math.random() * 3)];
    }
    if (msg.includes('yes') || msg.includes('yeah') || msg.includes('ok')) {
        return ['cool story', 'riveting stuff', 'and then wat happened'][Math.floor(Math.random() * 3)];
    }
    if (msg.includes('no') || msg.includes('nah')) {
        return ['ur loss', 'fair enough i guess', 'probably for the best'][Math.floor(Math.random() * 3)];
    }
    if (msg.includes('sorry') || msg.includes('my bad')) {
        return ['ur forgiven i suppose', 'apology accepted... barely', 'eh whatever'][Math.floor(Math.random() * 3)];
    }
    if (msg.includes('lol') || msg.includes('haha') || msg.includes('funny')) {
        return ['glad ur amused', 'comedy gold right here', 'peak humor achieved'][Math.floor(Math.random() * 3)];
    }
    
    // Default continuation responses
    return conversationResponses[Math.floor(Math.random() * conversationResponses.length)];
}

function cleanupExpiredConversations() {
    const now = Date.now();
    for (const [userId, conversation] of activeConversations) {
        if (now - conversation.lastActivity > CONVERSATION_TIMEOUT) {
            activeConversations.delete(userId);
            logger.info(`Cleaned up expired conversation for user ${userId}`);
        }
    }
}
