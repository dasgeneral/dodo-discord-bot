const logger = require('../utils/logger');

module.exports = {
    name: 'ready',
    once: true,
    execute(client) {
        logger.info(`Dodo Bot is ready! Logged in as ${client.user.tag}`);
        logger.info(`Bot is in ${client.guilds.cache.size} servers`);
        
        // Set bot status
        client.user.setActivity('eating and being lazy', { type: 'CUSTOM' });
        
        // Log some basic info
        logger.info(`Bot ID: ${client.user.id}`);
        logger.info('Dodo Bot is now online and ready to be grumpy! 🦤');
    },
};
