# Dodo Bot - Discord Bot

A grumpy Discord bot with personality that provides random reactions and contextual conversations.

## Features

- **Random Emoji Reactions**: Reacts to messages every ~4 messages
- **Sassy Replies**: Random grumpy responses every ~8 messages  
- **Contextual Conversations**: Smart keyword-based responses when pinged
- **Slash Commands**: `/say`, `/mood`, `/complain`, `/excuse`
- **Grumpy Personality**: Uses casual slang and intentional misspellings

## Commands

- `/say` - Get a random quirky phrase from Dodo
- `/mood` - Check Dodo's current mood (spoiler: grumpy)
- `/complain` - Hear Dodo complain about something
- `/excuse` - Get a creative excuse from Dodo

## Setup

1. Clone this repository
2. Install dependencies: `npm install`
3. Set up environment variables:
   - `DISCORD_TOKEN` - Your Discord bot token
   - `DISCORD_CLIENT_ID` - Your Discord application client ID
   - `DISCORD_GUILD_ID` - Your Discord server ID (optional, for faster testing)
4. Deploy commands: `node deploy-commands.js`
5. Start the bot: `npm start`

## Deployment

This bot is configured for Railway.app deployment. See deployment instructions in the main documentation.

## Bot Personality

Dodo Bot has a grumpy, lazy personality with phrases like:
- "wat u want man im eating"
- "stop bothering me"
- "go away plz"
- "ugh fine what"

The bot responds contextually to keywords and maintains its sarcastic character throughout all interactions.